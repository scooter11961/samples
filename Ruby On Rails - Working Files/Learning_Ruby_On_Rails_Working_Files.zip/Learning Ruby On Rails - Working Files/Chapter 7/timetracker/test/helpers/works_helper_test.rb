require 'test_helper'

class WorksHelperTest < ActionView::TestCase
end
