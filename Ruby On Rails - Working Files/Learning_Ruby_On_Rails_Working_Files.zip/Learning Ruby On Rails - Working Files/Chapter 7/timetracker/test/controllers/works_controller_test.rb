require 'test_helper'

class WorksControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
