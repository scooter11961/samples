require 'test_helper'

class CompaniesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
