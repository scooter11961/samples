def returnvals
	return 1,2,3,4
end

puts returnvals