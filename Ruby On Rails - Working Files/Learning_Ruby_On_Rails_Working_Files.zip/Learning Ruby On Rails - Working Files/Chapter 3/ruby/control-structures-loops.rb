x = 3
# while loop
puts 'while loop:'
while x < 10
	puts x
	x = x + 1
end

x = 3
# until loop
puts 'until loop:'
until x >= 10
	puts x
	x = x + 1
end

# times loop
puts 'times loop:'
3.times do
	puts 'I say this thrice'
end