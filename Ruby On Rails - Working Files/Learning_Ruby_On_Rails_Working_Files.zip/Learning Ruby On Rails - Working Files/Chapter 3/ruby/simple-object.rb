name = "brian"
name.upcase
puts name

name = "brian"
name.upcase!
puts name