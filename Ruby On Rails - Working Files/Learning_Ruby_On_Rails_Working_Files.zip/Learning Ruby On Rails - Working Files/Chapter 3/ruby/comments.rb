# here's a ruby comment

x = 3

=begin

  here's a mult-line
  comment

=end
	
puts x