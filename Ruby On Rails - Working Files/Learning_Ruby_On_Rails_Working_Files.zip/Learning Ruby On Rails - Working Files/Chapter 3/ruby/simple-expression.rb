x = 4
y = 2
print "x + y = "
puts x + y