str1 = "This is a string"
str2 = 'This is also a string'

puts str1
puts str2