str1 = "\a"
str2 = '\a'

puts str1
puts str2