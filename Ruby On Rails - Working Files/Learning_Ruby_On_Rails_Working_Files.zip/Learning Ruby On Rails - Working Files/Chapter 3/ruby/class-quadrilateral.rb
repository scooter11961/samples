class Quadrilateral
	def num_sides
		4
	end
end

quad = Quadrilateral.new

puts "I am a quadrilateral"
print "I have this many sides: "
puts quad.num_sides