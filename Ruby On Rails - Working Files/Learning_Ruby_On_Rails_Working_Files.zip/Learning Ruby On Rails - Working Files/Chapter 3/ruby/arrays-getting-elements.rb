arr = [10,20,30,40,50]

puts arr[0] #returns 10

puts
puts '*****'
puts

puts arr[-2] #returns 40

puts
puts '*****'
puts

puts arr[2,3] #returns [30,40,50]

puts
puts '*****'
puts

puts arr[2..3] #return [30,40]