str = "hello world"
puts str