require 'test_helper'

class UsermailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
